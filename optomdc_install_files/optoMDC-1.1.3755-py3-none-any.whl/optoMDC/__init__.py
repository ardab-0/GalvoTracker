from .mre2 import MRE2Board as connect
from .tools.definitions import *

__version__ = '1.1.3755'
__git_version__ = 'c4b39479dd396a400d57306713f551c6d00acddf'
