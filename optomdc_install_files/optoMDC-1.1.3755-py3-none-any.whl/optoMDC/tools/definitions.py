from enum import IntEnum

# Kummenberg Internal Definitions
from optoKummenberg.tools.definitions import *

# MRE2 Specific Definitions
MRE2_CHANNEL_CNT = 2
